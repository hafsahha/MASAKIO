package com.example.masakio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
